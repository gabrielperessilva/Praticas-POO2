public interface Component{

    public void andar(Personagem p);
}
