public class Saida implements Component{


    public void andar(Personagem p){ 
        System.out.println("--------------------------------------------------------");
        System.out.println("Saída encontrada personagem "+p.getNome()+" venceu");
       }

}
