public class Abismo implements Component{


    public void jogar(Personagem p){ 
        System.out.println("--------------------------------------------------------");
        System.out.println("Abismo encontrado. Game over. Personagem morreu..."+p.getNome());
       }

}
