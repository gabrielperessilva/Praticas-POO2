public interface Component{

    public void jogar(Personagem p);
}
