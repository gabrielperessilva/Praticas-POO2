public class Saida implements Component{


    public void jogar(Personagem p){ 
        System.out.println("--------------------------------------------------------");
        System.out.println("Saída encontrada personagem "+p.getNome()+" venceu");
       }

}
