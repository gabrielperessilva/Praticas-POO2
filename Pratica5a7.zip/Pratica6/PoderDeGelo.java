public class PoderDeGelo extends AtaqueDecorador {
    public PoderDeGelo(Ataque ataqueDecorador) {
        super(ataqueDecorador);
        setDescricao("Poder de gelo");
    }
}
