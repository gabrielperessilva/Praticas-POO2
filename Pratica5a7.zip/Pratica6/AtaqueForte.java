
/**
 * Escreva uma descrição da classe CorrerDevagar aqui.
 * 
 * @author (seu nome) 
 * @version (um número da versão ou uma data)
 */
public class AtaqueForte extends Ataque
{
    public AtaqueForte(){
        this.setDescricao("Ataque Forte");
    }
}
