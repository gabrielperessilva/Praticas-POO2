public class PoderDeFogo extends AtaqueDecorador {
     public PoderDeFogo(Ataque ataqueDecorador) {
     super(ataqueDecorador);
     setDescricao("Poder de fogo");
     }
}