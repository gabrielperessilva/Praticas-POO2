
/**
 * Escreva uma descrição da classe CorrerDevagar aqui.
 * 
 * @author (seu nome) 
 * @version (um número da versão ou uma data)
 */
public class AtaqueMedio extends Ataque
{
    public AtaqueMedio(){
        this.setDescricao("Ataque Medio");
    }
}
