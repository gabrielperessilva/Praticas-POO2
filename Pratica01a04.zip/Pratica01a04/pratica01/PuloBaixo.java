package pratica01;


/**
 * Escreva uma descrição da classe PuloBaixo aqui.
 * 
 * @author (seu nome) 
 * @version (um número da versão ou uma data)
 */
public class PuloBaixo implements Pulo
{
    public void pular(){
        System.out.println("Pulo baixo");
    }
}
