package pratica01;


/**
 * Escreva a descrição da interface Corre aqui.
 * 
 * @author (seu nome aqui) 
 * @version (um número da versão ou data aqui)
 */

public interface Corre
{
    public void correr();
}
