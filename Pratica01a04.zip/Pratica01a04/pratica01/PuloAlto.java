package pratica01;


/**
 * Escreva uma descrição da classe PuloAlto aqui.
 * 
 * @author (seu nome) 
 * @version (um número da versão ou uma data)
 */
public class PuloAlto implements Pulo
{
    public void pular(){
        System.out.println("Pulo alto");
    }
}
