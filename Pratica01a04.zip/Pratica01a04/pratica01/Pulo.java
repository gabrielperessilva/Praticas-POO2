package pratica01;


/**
 * Escreva a descrição da interface Pulo aqui.
 * 
 * @author (seu nome aqui) 
 * @version (um número da versão ou data aqui)
 */

public interface Pulo
{
    public void pular();
}
