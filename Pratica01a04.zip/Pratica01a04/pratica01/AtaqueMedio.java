package pratica01;


/**
 * Escreva uma descrição da classe CorrerDevagar aqui.
 * 
 * @author (seu nome) 
 * @version (um número da versão ou uma data)
 */
public class AtaqueMedio implements Ataque
{
    public void atacar(){
        System.out.println("Ataque medio");
    }
}
