package pratica01;


/**
 * Escreva uma descrição da classe PuloMedio aqui.
 * 
 * @author (seu nome) 
 * @version (um número da versão ou uma data)
 */
public class PuloMedio implements Pulo
{
    public void pular(){
        System.out.println("Pulo medio");
    }
}
