package pratica02.acao;


/**
 * Escreva a descrição da interface Ataque aqui.
 * 
 * @author (seu nome aqui) 
 * @version (um número da versão ou data aqui)
 */

public interface Ataque
{
    public void atacar();
}
