package pratica02.acao;


/**
 * Escreva a descrição da interface Corre aqui.
 * 
 * @author (seu nome aqui) 
 * @version (um número da versão ou data aqui)
 */

public interface Velocidade
{
    public void velocidade();
}
