package pratica02.acao;


/**
 * Escreva uma descrição da classe CorrerDevagar aqui.
 * 
 * @author (seu nome) 
 * @version (um número da versão ou uma data)
 */
public class VelocidadeMedia implements Velocidade
{
    public void velocidade(){
        System.out.println("Velocidade Media");
    }
}
